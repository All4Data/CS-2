try:
    hrs = float(input ('Enter Hours: '))
    try:
        rate = float(input ('Enter Rate: '))
        normal = 40.0
        if hrs <= normal :
            print ('Pay = ', hrs * rate)
        else :
            print ('Pay = ', (normal * rate) + ((hrs - 40) * (rate * 1.5)))
    except:
        print ('Error, please enter numeric input')

except:
    print ('Error, please enter numeric input')
